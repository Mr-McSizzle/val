document.getElementById('yes-button').addEventListener('click', function() {
    alert('Yay! I\'m so happy!');
});

document.getElementById('no-button').addEventListener('click', function() {
    alert('Oh no! Maybe next time.');
});